import React, { useMemo, useState } from 'react';
import { FileTree } from './components/FileTree';
import { CodeViewer } from './components/CodeViewer';
import { Dashboard } from './components/Dashboard';
import { UploadPanel } from './components/UploadPanel';
import { ShieldCheck, RotateCcw } from 'lucide-react';

import type { AnalysisResult, FileData } from './types/analysis';
import { BuildFileTree } from './utils/BuildFileTree';

const App: React.FC = () => {
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [selectedFile, setSelectedFile] = useState<FileData | null>(null);

  const fileTree = useMemo(() => {
    if (!analysisResult) {
      return [];
    }

    return BuildFileTree(analysisResult.files);
  }, [analysisResult]);

  const selectedFileFindings = useMemo(() => {
    if (!analysisResult || !selectedFile) {
      return [];
    }

    return analysisResult.findings.filter(
      (finding) => finding.file_path === selectedFile.path
    );
  }, [analysisResult, selectedFile]);

  const handleSelectFile = (file: FileData) => {
    if (file.type === 'file') {
      setSelectedFile(file);
    }
  };

  const handleReset = () => {
    setAnalysisResult(null);
    setSelectedFile(null);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-background text-gray-800">
      <header className="h-12 border-b border-gray-200 bg-white flex items-center px-4 shrink-0 shadow-sm z-20">
        <ShieldCheck className="text-indigo-600 mr-2" size={20} />
        <h1 className="font-bold text-gray-800 tracking-tight text-sm">
          SAST<span className="font-light text-gray-500">Analyzer</span>
        </h1>

        {analysisResult && (
          <div className="ml-4 text-xs text-gray-500">
            Score: {analysisResult.project_score}/100 · Risk: {analysisResult.overall_risk} · Findings: {analysisResult.total_findings}
          </div>
        )}

        {analysisResult && (
          <button
            onClick={handleReset}
            className="ml-auto text-xs text-gray-600 hover:text-indigo-600 flex items-center"
          >
            <RotateCcw size={14} className="mr-1" />
            New scan
          </button>
        )}
      </header>

      {!analysisResult ? (
        <UploadPanel onAnalyzeComplete={setAnalysisResult} />
      ) : (
        <>
          <div className="flex-1 flex overflow-hidden">
            <FileTree
              data={fileTree}
              onSelectFile={handleSelectFile}
              selectedFileId={selectedFile?.id || null}
            />

            <CodeViewer
  file={selectedFile}
  findings={selectedFileFindings}
/>
          </div>

          <Dashboard result={analysisResult} />
        </>
      )}
    </div>
  );
};

export default App;