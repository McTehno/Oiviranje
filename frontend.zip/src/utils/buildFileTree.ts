import type { FileData } from '../types/analysis';

export function BuildFileTree(files: FileData[]): FileData[] {
  const root: FileData[] = [];

  files.forEach((file) => {
    const parts = file.path.split(/[\\/]/);
    let currentLevel = root;

    parts.forEach((part, index) => {
      const currentPath = parts.slice(0, index + 1).join('/');
      const isFile = index === parts.length - 1;

      let existing = currentLevel.find((item) => item.path === currentPath);

      if (!existing) {
        existing = {
          id: currentPath,
          name: part,
          path: currentPath,
          type: isFile ? 'file' : 'folder',
          children: isFile ? undefined : [],
        };

        currentLevel.push(existing);
      }

      if (isFile) {
        Object.assign(existing, file);
      } else {
        currentLevel = existing.children!;
      }
    });
  });

  return root;
}