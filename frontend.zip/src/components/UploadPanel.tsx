import React, { useState } from 'react';
import { Upload, ShieldCheck } from 'lucide-react';
import { analyzeProject } from '../api/analyzerApi';
import type { AnalysisResult } from '../types/analysis';

interface UploadPanelProps {
  onAnalyzeComplete: (result: AnalysisResult) => void;
}

export const UploadPanel: React.FC<UploadPanelProps> = ({ onAnalyzeComplete }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [database, setDatabase] = useState('mysql');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!selectedFile) {
      setError('Please select a ZIP project file.');
      return;
    }

    try {
      setError(null);
      setIsAnalyzing(true);

      const result = await analyzeProject(selectedFile, {
        mode: 'single',
        default_database: database,
        folder_databases: {},
      });

      onAnalyzeComplete(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex-1 flex items-center justify-center bg-gray-50">
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-8 w-full max-w-xl">
        <div className="flex items-center mb-6">
          <ShieldCheck className="text-indigo-600 mr-3" size={28} />
          <div>
            <h2 className="text-xl font-bold text-gray-900">Analyze Project</h2>
            <p className="text-sm text-gray-500">
              Upload a ZIP project and scan it for injection vulnerabilities.
            </p>
          </div>
        </div>

        <div className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Project ZIP
            </label>
            <input
              type="file"
              accept=".zip"
              onChange={(event) => setSelectedFile(event.target.files?.[0] || null)}
              className="block w-full text-sm text-gray-700 border border-gray-300 rounded-md p-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Default Database
            </label>
            <select
              value={database}
              onChange={(event) => setDatabase(event.target.value)}
              className="block w-full border border-gray-300 rounded-md p-2 text-sm"
            >
              <option value="mysql">MySQL</option>
              <option value="mongodb">MongoDB</option>
            </select>
          </div>

          {error && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md p-3">
              {error}
            </div>
          )}

          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="w-full bg-indigo-600 text-white rounded-md py-2.5 text-sm font-semibold flex items-center justify-center disabled:opacity-60"
          >
            <Upload size={16} className="mr-2" />
            {isAnalyzing ? 'Analyzing...' : 'Analyze Project'}
          </button>
        </div>
      </div>
    </div>
  );
};